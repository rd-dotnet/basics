﻿namespace ConsoleApp12
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            //ExecuteScalarExample.ShowExample();
            //ExecuteNonQueryExample.ShowExample();
            //ExecuteReaderExample.ShowExample();
            //ParametersExample.ShowExample();
            CommandAsStoredProcedureExample.ShowExample();
        }
    }
}